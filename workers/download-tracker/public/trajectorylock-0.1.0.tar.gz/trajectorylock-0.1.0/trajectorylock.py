#!/usr/bin/env python3
"""TrajectoryLock CLI entry.

Author: Aziel Eliab. Apache-2.0.
"""

from trajectorylock.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
